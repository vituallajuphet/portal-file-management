<?php
  echo "You are not allowed to access this page.";
   exit;
?>