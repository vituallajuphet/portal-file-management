
<aside class="left-sidebar">
        <!-- Sidebar scroll-->
        <div class="scroll-sidebar">
            <!-- Sidebar navigation-->
            <nav class="sidebar-nav">
                <ul id="sidebarnav">
                     <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("cbmc/investors")?>" aria-expanded="false"><i class="icon-Money-2"></i><span class="hide-menu">Investors </span></a>
                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("cbmc/companies")?>" aria-expanded="false"><i class="icon-Building "></i><span class="hide-menu">Subsidiary </span></a>
                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("cbmc/manage_request")?>" aria-expanded="false"><i class="icon-Notepad-2 "></i><span class="hide-menu">Manage Requests </span></a>
                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("cbmc/manage_files")?>" aria-expanded="false"><i class="icon-Files"></i><span class="hide-menu">Manage Files </span></a>
                    </li>
                   

                </ul>
            </nav>
            <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
    </aside>