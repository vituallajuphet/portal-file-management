<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/module/bootstrap2.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/module/datatable-bootstrap.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/module/datatable-responsive.css">


	<style>
		thead {
			background-color: #c5a36f;
			/* border-radius: 6px; */
		}

		.table thead th {
		    border: 0px;
		}
		th.sorting {}

		thead tr:first-child th:first-child {
		    border-top-left-radius: 10px;
		    border-bottom-left-radius: 10px;
		}

		thead tr:first-child th:last-child {
		    border-top-right-radius: 10px;
		    border-bottom-right-radius: 10px;
		    /* overflow: hidden; */
		}
		/* tr:first-child td:first-child { border-top-left-radius: 10px; }
		tr:first-child td:last-child { border-top-right-radius: 10px; } */
	</style>
