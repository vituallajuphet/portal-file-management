
<aside class="left-sidebar">
        <!-- Sidebar scroll-->
        <div class="scroll-sidebar">
            <!-- Sidebar navigation-->
            <nav class="sidebar-nav">
                <ul id="sidebarnav">
                    <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("admin/manage_users")?>" aria-expanded="false"><i class="icon-Administrator "></i><span class="hide-menu">Manage Company Users </span></a>
                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("admin/department_user")?>" aria-expanded="false"><i class="icon-User"></i><span class="hide-menu">Manage Department Users </span></a>
                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("admin/companies")?>" aria-expanded="false"><i class="icon-Building "></i><span class="hide-menu">Manage Companies </span></a>
                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("admin/manage_request")?>" aria-expanded="false"><i class="icon-Notepad-2 "></i><span class="hide-menu">Manage Requests </span></a>
                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("admin/manage_files")?>" aria-expanded="false"><i class="icon-Files"></i><span class="hide-menu">Manage Files </span></a>
                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="<?= base_url("admin/investors")?>" aria-expanded="false"><i class="icon-Money-2"></i><span class="hide-menu">Investors </span></a>
                    </li>

                </ul>
            </nav>
            <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
    </aside>