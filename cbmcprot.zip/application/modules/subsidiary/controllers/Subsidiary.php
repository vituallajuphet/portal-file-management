<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subsidiary extends MY_Controller {

		public function index(){
			echo "Subsidiary page coming soon...";
		}

}
