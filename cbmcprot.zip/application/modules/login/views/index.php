
<div id="myApp">
    <div class="login_cont">
       <transition name="fade" mode="out-in">
                <router-view></router-view>
        </transition>
    </div>
</div>
